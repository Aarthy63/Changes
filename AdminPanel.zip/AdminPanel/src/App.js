import React, { Component, Suspense } from 'react'
import { Route, Routes, Navigate } from 'react-router-dom'
import './scss/style.scss'
import DefaultLayout from './layout/DefaultLayout'
import Register from './views/pages/register/Register'
import Page404 from './views/pages/page404/Page404'
import Page500 from './views/pages/page500/Page500'
import Login from './views/pages/login/Login'
import LoginOtp from './views/pages/login/LoginOtp';
import ForgotPasswordOtp from './views/pages/login/ForgotPasswordOtp'
import ForgetPassword from './views/pages/login/Forgotpassword';
import SetnewPassword from './views/pages/login/SetnewPassword';
import Changepassword from './views/pages/ChangePassword/ChangePassword'; 
import TwoFactorAuth from './views/pages/TwoFactor/TwoFactorAuth'
import ForgotPattern from './views/pages/Forgotpattern/ForgotPattern';
import UserList from './views/users/UserList';
import ForgotPassword from './views/pages/TwoFactor/ForgetPassword'
import EmailVerify from './views/pages/Forgotpattern/EmailVerify'
import Forgot from './views/pages/Forgotpattern/Forgot'
import FactorAuth from './views/pages/TwoFactor/FactorAuth';
import KycSingleData from './views/Kyc/KycSingledata'
import KycList from './views/Kyc/KycList'

const loading = (
  <div className="pt-3 text-center">
    <div className="sk-spinner sk-spinner-pulse"></div>
  </div>
)

class App extends Component {
  render() {
    return (
          <Routes>
            <Route exact path='*' element={<DefaultLayout />}/>
            <Route exact path="/register" name="Register Page" element={<Register />} />
            <Route exact path="/404" element={<Page404 />} />
            <Route exact path="/500" element={<Page500 />} />
            <Route exact path="/ForgotPasswordOtp" element={<ForgotPasswordOtp />} />
            <Route exact path="/ForgetPassword" element={<ForgetPassword />} />
            <Route exact path="/500" element={<Page500 />} />
            <Route exact path="/SetnewPassword" element={<SetnewPassword />} />
            <Route path="/" element={<Login />} />
            <Route path='/TwoFactorAuth' element = {<TwoFactorAuth />} />
            <Route exact path="/LoginOtp" element={<LoginOtp />} />
            <Route exact path = "/Changepassword" element = {<Changepassword />}/>
            <Route exact path = "/ForgotPattern" element = {<ForgotPattern />}/>
            <Route exact path='users/UserList/:id' element = {<UserList />} />
            <Route path = "/ForgotPassword" element ={<ForgotPassword />}/>
            {/* <Route exact path="/500" element={<Page500 />} /> */}
            <Route path= '/EmailVerify' element = {<EmailVerify />}/>
            <Route path= '/Forgot' element={<Forgot />}/>
             <Route path='/FactorAuth' element={<FactorAuth />}/>
             <Route path='KycSingleData/:id' element = {<KycSingleData />}/>
             <Route path='/KycList' element= {<KycList />}/>
          </Routes>
     
    )
  }
}

export default App
