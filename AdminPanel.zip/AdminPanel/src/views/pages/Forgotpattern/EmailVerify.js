// import React, { useState } from 'react'
// import { useForm } from 'react-hook-form'
// import { yupResolver } from '@hookform/resolvers/yup'
// import * as yup from 'yup'
// import { useNavigate } from 'react-router-dom'
// import { useGetTwoFactorAuthenticationMutation, useVerfiyEmailMutation } from '../../../redux/services/adminAPI'
// import { toast } from 'react-toastify'
// const schema = yup.object().shape({
//   email: yup.string().required('Email is required').email('Invalid email'),
// })
// const EmailVerifyForgotPassword = () => {
//   const navigate = useNavigate()
//   const [showPassword, setShowPassword] = useState(false)
//   const {
//     register,
//     handleSubmit,
//     formState: { errors },
//   } = useForm({
//     resolver: yupResolver(schema),
//     mode: 'all',
//   })
//   const [verfiyEmail] = useVerfiyEmailMutation()
//   const onSubmit = async (data) => {
//     try {
//       const response = await verfiyEmail(data)
//       console.log(response)
//       if (response.error) {
//         toast.error(response.error.data.message)
//       } else {
//         toast.success(response.data.message)
//         navigate('/ForgotPattern')
//       }
//     } catch (error) {
//       toast.error(error.message)
//     }
//   }
//   return (
//     <div className="d-grid justify-content-center align-items-center vh-100">
//       <div className="card" style={{ width: '18rem' }}>
//         <div className="card-body">
//           <h5 className="card-title">Verify Your Email</h5>
//           <form onSubmit={handleSubmit(onSubmit)}>
//             <div className="form-row  ">
//               <div className="form-group col">
//                 <input
//                   name="email"
//                   type="text"
//                   placeholder="you@mail.com"
//                   {...register('email')}
//                   className={`form-control  mb-3 ${errors.email ? 'is-invalid' : ''}`}
//                 />
//                 <div className="invalid-feedback">{errors.email?.message}</div>
//               </div>
//             </div>

//             <div className="form-group d-grid mt-4">
//               <button type="submit" className="btn btn-outline-danger mr-1">
//                 Verify Here..
//               </button>
//             </div>
//           </form>
//         </div>
//       </div>
//     </div>
//   )
// }

// export default EmailVerifyForgotPassword

import React from 'react'
import email from '../../../assets/images/avatars/OTP.gif'
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useNavigate } from 'react-router-dom';
import { useVerfiyEmailMutation } from '../../../redux/services/adminAPI';
import { toast } from 'react-toastify';

const validationSchema = Yup.object().shape({
    email: Yup.string().required('Email is required').email('Email is invalid')
        .matches(/^[a-z0-9]+@[a-z]+\.[a-z]{2,3}$/, 'enter valid email').trim()

});

const ForgetPatternEmailVerify = () => {

    const navigate = useNavigate()

    const { register, handleSubmit, formState: { errors } } = useForm({
        resolver: yupResolver(validationSchema),
        mode: 'all'
    });

    // RTK Query 
    const [verifyEmail] = useVerfiyEmailMutation()


    const handleVerifyEmail = async (data) => {

        try {
            const response = await verifyEmail(data)
            if (response.error) {
                return toast.error(response.error.data.message, {
                    position: toast.POSITION.TOP_CENTER
                })
            }
            localStorage.setItem('adminId', response.data.adminData._id)
            const twoFactorStatus = response.data.adminData.authVerify
            if (!twoFactorStatus) {
                localStorage.setItem('forgetPattern', true)
                navigate('/FactorAuth')
                return
            }
            navigate('/TwoFactorAuth')

        } catch (error) {
            console.log(error.message);
        }
    }

    return (
        <>
            <div className='p-4 twoFactor-Bg' style={{ minHeight: "100vh" }}>
                <h1 className='text-center mb-5' >Security</h1>
                <div className='row'>
                    <div className='col-lg-5'>
                        <form onSubmit={handleSubmit(handleVerifyEmail)}>
                            <div className='mb-5'>
                                <h1>Enter Your Email</h1>
                                <div className="mb-3">
                                    <input
                                        type="email"
                                        className={`form-control  ${errors?.email ? 'is-invalid' : ''
                                            }`}
                                        name='email'
                                        {...register('email')}
                                        id="exampleFormControlInput1"
                                        placeholder="name@example.com" />
                                    <div className="invalid-feedback ">
                                        <span>{errors?.email?.message}</span>
                                    </div>
                                </div>

                                <div className='d-grid my-3 '>
                                    <button className='btn btn-dark' type="submit">Verify</button>
                                </div>
                            </div>
                        </form>
                    </div>

                    <div className='col-lg-6'>
                        <img src={email} className='img-fluid rounded' alt="" />
                    </div>
                </div>
            </div>
        </>
    )
}

export default ForgetPatternEmailVerify
