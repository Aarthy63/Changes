import React, { Fragment, useState } from
 
"react";
import { useForm } from
 
'react-hook-form';
import { yupResolver } from
 
'@hookform/resolvers/yup';
import * as Yup from
 
'yup';
import {
  useChangePasswordMutation
} from "../../../redux/services/adminAPI";
// import OtpInput from 'react-otp-input';
// import { Button, Modal, ModalBody, ModalFooter } from "reactstrap";
import Swal from "sweetalert2";
import { useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";


const schema = Yup.object().shape({

  oldPassword: Yup.string().required ('Old Password us required'),
  password: Yup.string().required('Password is required').matches(/[A-Z]/, 'Please Give One UpperCase Letter').matches(/[0-9]/, 'Please One Number').matches(/[-!$%^&*()_+|~=`{}[\]:/;<>?,.@#]/, 'Please Give Special Character.. like @#$').trim().min(8, 'Password must be at least 8 characters'),
  confirmPassword: Yup.string()
        .oneOf([Yup.ref('password'), null], 'Passwords does not match')
        .required('Confirm Password is required').trim(),
});

const ChangePassword = (props) => {
    const navigate= useNavigate();
    const getLoggedUserId = localStorage.getItem('adminId')
    const [changePassword] = useChangePasswordMutation();
  // const [modal, setModal] = useState(false);
  // const [otp, setOtp] = useState("");

 

  const { register, handleSubmit, formState:
     { errors },
  reset, } = useForm({
    resolver: yupResolver(schema),
  });

  const onSubmit = async (data) => {
    console.log(data);

    try {
        const response = await changePassword({ id: getLoggedUserId, password: data.password, newPassword: data.newPassword });
        reset()
        console.log(response);
        if (response.error) {
            toast.error("Incorrect old password")
        } else {
            toast.success('Password has been changed')
            setTimeout(() => {
                navigate('/TwoFactorAuth')
            }, 4000);
        }
    } catch (error) {
        toast.error("Incorrect old password")
        console.log(error)
}
  }
  // const onSubmit = async (data) => {
  //   try {
  //     await forgotPwd(data);
  //     // setModal(true);
  //   } catch (error) {
  //     console.error("Forgot password failed", error);
  //     toast.error("An unexpected error occurred.");
  //   }
  // };

  // const toggle = () => {
  //   setModal(!modal);
  //   setOtp("");
  // };
  

  return (
    <Fragment>
      
      <div className="Main-section cmsSec" style={{ paddingTop: '80px' }}>
        <div className="container container-1200">
          <div className="row justify-content-center">
            <div className="col-lg-8">
              <div className="LgnPg">
                {/* <img src={logo} className="img-fluid d-block mx-auto" /> */}
                <h3>Change Password</h3>
                <form className="p-5 rounded h-100 mb-5" onSubmit={handleSubmit(onSubmit)}>
                <div className="form-group">
                
                  <input
                    type="text"
                    className={`form-control ${errors.oldPassword ? 'is-invalid' : ''}`}
                    placeholder="Enter you old password"
                    {...register('oldPassword')}
                  />
                  {errors.oldPassword && (
                    <div className="invalid-feedback">{errors.oldPassword.message}
                    </div>
                  )}
                </div>

                <div className="form-group">
          
                  <input
                    type="text"
                    className={`form-control ${errors.password ? 'is-invalid' : ''}`}
                    placeholder="Enter you new password"
                    {...register('password')}
                  />
                  {errors.password && (
                    <div className="invalid-feedback">{errors.password.message}
                    </div>
                  )}
                </div>
                <div className="form-group">
          
                  <input
                    type="text"
                    className={`form-control ${errors.confirmPassword ? 'is-invalid' : ''}`}
                    placeholder="Enter you confirm password"
                    {...register('confirmPassword')}
                  />
                  {errors.confirmPassword && (
                    <div className="invalid-feedback">{errors.confirmPassword.message}
                    </div>
                  )}
                </div>
                <button className="btn LGn-btn">Send</button>
                <p>Didn’t receive the OTP ?<a href="#" className="ml-2">Resend OTP</a></p>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    
   
    </Fragment>
  );

}

export default ChangePassword;
       