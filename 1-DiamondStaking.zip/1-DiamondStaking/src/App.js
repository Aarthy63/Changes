import React, { Component, Suspense } from 'react';
import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../src/style.scss';
import {
   BrowserRouter, Navigate, Route, Routes
} from 'react-router-dom';

import Home from './views/Home/Home';
import Innerpages from './views/Innerpages/Innerpages';
import Proposal from './views/Proposal/Proposal';
import NewProposal from './views/NewProposal/NewProposal';
import ProposalDetails from './views/ProposalDetails/ProposalDetails';
import Settings from './views/Settings/Settings';
import Voting from './views/Voting/Voting';
import Members from './views/Members/Members';
import Terms from './views/Terms/Terms';
import Privacy from './views/Privacy/Privacy';
import Faq from './views/Faq/Faq';
import Login from './views/Login/Login';
import Register from './views/Register/Register';
import ForgotPassword from './views/ForgotPassword/ForgotPassword';
import KYC from './views/KYC/KYC';
import BuyPlan from './views/BuyPlan/BuyPlan';
import PlanList from './views/PlanList/PlanList';
import Stake from './views/Stake/Stake';
import Unstake from './views/Unstake/Unstake';
import StakeOne from './views/StakeOne/StakeOne';
import About from './views/About/About';
import TransactionHistory from './views/TransactionHistory/TransactionHistory';
import ChangePassword from './views/ChangePassword/ChangePassword';
// import VerifyEmail from './views/VerifyEmail/VerifyEmail';
import ForgotPasswordOtp from './views/ForgotPassword/ForgotPasswordOtp'
import RegisterOtp from './views/Register/RegisterOtp';
import LoginOtp from './views/Login/LoginOtp'
import FASecurityPage from './views/SecurityPage/FASecurityPage';
import Getaccounts from './views/getaccounts/Getaccounts';



const App = (props) => {
   return (
      <React.Fragment>
         <BrowserRouter>
            <Routes history={props.history}>
              <Route path='/' element={<Home />} />
              <Route path='*' element={<Innerpages />} />
              <Route path='/proposal' element={<Proposal />} />
              <Route path='/newproposal' element={<NewProposal />} />
              <Route path='/proposaldetails' element={<ProposalDetails />} />
              <Route path='/settings' element={<Settings />} />
              <Route path='/voting' element={<Voting />} />
              <Route path='/members' element={<Members />} />
              <Route path='/terms' element={<Terms />} />
              <Route path='/privacy' element={<Privacy />} />
              <Route path='/faq' element={<Faq />} />
              <Route path='/login' element={<Login />} />
              <Route path='/LoginOtp' element={<LoginOtp />} />
              <Route path='/ChangePassword' element={<ChangePassword />} />
              <Route path='/register' element={<Register />} />
              <Route path='/RegisterOtp' element={<RegisterOtp />} />
              <Route path='/FASecurityPage' element={<FASecurityPage />} />
              {/* <Route path='VerifyEmail' element={<VerifyEmail />} /> */}
              <Route path='/Forgotpassword' element={<ForgotPassword />} />
              <Route path='/kyc' element={<KYC />} />
              <Route path='/buyplan' element={<BuyPlan />} />
              <Route path='/planlist' element={<PlanList />} />
              <Route path='/stake' element={<Stake />} />
              <Route path='/unstake' element={<Unstake />} />
              <Route path='/about' element={<About />} />
              <Route path='/thistory' element={<TransactionHistory />} />
              <Route path='/ForgotPasswordOtp' element={<ForgotPasswordOtp />}/>
              <Route path= '/Getaccounts' element={<Getaccounts />}/>
             
            </Routes>
         </BrowserRouter>
      </React.Fragment>
   );
}

export default App;